OPENAI_API_KEY = "your-api-key"
MODEL = "gpt-4o-mini"
MAX_RETRY = 2
